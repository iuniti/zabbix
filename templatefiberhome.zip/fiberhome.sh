#!/bin/bash
snmpwalk -On -v2c -c adsl 10.2.1.7 1.3.6.1.4.1.5875.800.3.9.3.3.1.2 > /usr/lib/zabbix/externalscripts/arquivo/posicao/10.2.1.7
sleep 10
snmpwalk -On -v2c -c adsl 10.2.1.7 1.3.6.1.4.1.5875.800.3.10.1.1.11 > /usr/lib/zabbix/externalscripts/arquivo/status/10.2.1.7
sleep 10
snmpwalk -On -v2c -c adsl 10.2.1.4 1.3.6.1.4.1.5875.800.3.9.3.3.1.2 > /usr/lib/zabbix/externalscripts/arquivo/posicao/10.2.1.4
sleep 10
snmpwalk -On -v2c -c adsl 10.2.1.4 1.3.6.1.4.1.5875.800.3.10.1.1.11 > /usr/lib/zabbix/externalscripts/arquivo/status/10.2.1.4
sleep 10
snmpwalk -On -v2c -c adsl 10.2.1.2 1.3.6.1.4.1.5875.800.3.9.3.3.1.2 > /usr/lib/zabbix/externalscripts/arquivo/posicao/10.2.1.2
sleep 10
snmpwalk -On -v2c -c adsl 10.2.1.2 1.3.6.1.4.1.5875.800.3.10.1.1.11 > /usr/lib/zabbix/externalscripts/arquivo/status/10.2.1.2
